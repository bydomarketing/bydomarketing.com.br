export type BlogArticle = {
  slug: string;
  title: string;
  description: string;
  category: string;
  publishedAt: string;
  updatedAt?: string;
  readingTime: string;
  image?: string;
  imageAlt?: string;
  introduction: string;
  sections: readonly {
    heading: string;
    paragraphs: readonly string[];
  }[];
  relatedService?: {
    label: string;
    href: string;
  };
};

// Os artigos entram nesta coleção somente quando o conteúdo estiver concluído.
// Dessa forma, o site não publica URLs vazias ou páginas provisórias indexáveis.
export const articles: readonly BlogArticle[] = [];

export function findArticle(slug: string) {
  return articles.find((article) => article.slug === slug);
}
